import mongoose from "mongoose";

const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    content: { type: String, required: true, trim: true },
    author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    category: { type: mongoose.Schema.Types.ObjectId, ref: "PostCategory", required: true },
    published: { type: Boolean, default: false }
  },
  { timestamps: true }
);

const Post = mongoose.model("Post", postSchema);
export default Post;
